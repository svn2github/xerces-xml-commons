package org.apache.xerces.xinclude;
import org.apache.xerces.xni.parser.XMLComponent;
import org.apache.xerces.xni.parser.XMLDocumentFilter;



public interface XPointerSchema extends XMLComponent, XMLDocumentFilter{

    /**
     * set the Schema Name  eg element , xpointer
     */
    public void setXPointerSchemaName(String schemaName);

    /**
     * Return  Schema Name  eg element , xpointer
     *
     */
    public String getXpointerSchemaName();

    /**
     * Parent Contenhandler for the this contenthandler.
     * // not sure about the parameter type. It can be Contenthandler instead of Object type.
     */
    public void setParent(Object parent);

    /**
     * return the Parent Contenthandler
     */
    public Object getParent();

    /**
     * Content of the XPointer Schema. Xpath to be resolved.
     */
    public void setXPointerSchemaPointer(String content);

    /**
     * Return the XPointer Schema.
     */
    public String getXPointerSchemaPointer();

    public boolean isSubResourceIndentified();

    public void reset();

}
